import { ValidarNombreDirective } from './validar-nombre.directive';

describe('ValidarNombreDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidarNombreDirective();
    expect(directive).toBeTruthy();
  });
});
