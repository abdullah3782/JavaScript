import { ValidarPasswordDirective } from './validar-password.directive';

describe('ValidarPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidarPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
