import { MayorEdadDirectiveDirective } from './mayor-edad-directive.directive';

describe('MayorEdadDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MayorEdadDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
